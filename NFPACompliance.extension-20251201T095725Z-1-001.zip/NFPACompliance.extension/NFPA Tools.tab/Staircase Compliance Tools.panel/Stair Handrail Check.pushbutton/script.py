# -*- coding: utf-8 -*-
# pyRevit | NFPA Stair Handrail Check (IronPython-safe, patched for Architecture namespace)
# Checks:
#   - Minimum number of railings per stair (>=1; >=2 if widest run >= threshold)
#   - Handrail height within range (mm)
#   - Hand clearance from wall (mm), if a parameter is available

from pyrevit import revit, DB, script
from System.Collections.Generic import List as ClrList

# ---- import Architecture namespace (this fixes the 'DB.Stairs' attribute error) ----
Arch = DB.Architecture

# ---------------- USER SETTINGS ----------------
MIN_HEIGHT_MM = 865.0    # ~34 in
MAX_HEIGHT_MM = 965.0    # ~38 in
MIN_CLEARANCE_MM = 38.0  # ~1.5 in (from wall/obstruction)

# Require two handrails when a stair's WIDEST run width is >= this value
DUAL_HANDRAIL_AT_WIDTH_MM = 1100.0

HIGHLIGHT = True
SELECT    = False
# ------------------------------------------------

doc   = revit.doc
uidoc = revit.uidoc
view  = doc.ActiveView
out   = script.get_output()

FT_TO_MM = 304.8

# Candidate BuiltInParameters (may vary by version/content)
BIP_HEIGHT_CAND = [
    "RAILING_HEIGHT",
    "STAIRS_ACTUAL_RAILING_HEIGHT",
    "HANDRAIL_HEIGHT",
]

# Named params seen in families/templates (case sensitive in LookupParameter)
NAME_HEIGHT_CAND = [
    "Height",
    "Top Height",
    "Handrail Height",
    "Handrail Height (proj)",
]

# Clearance param name guesses (no stable BIP)
NAME_CLEAR_CAND = [
    "Hand Clearance",
    "Clearance",
    "Grasp Clearance",
]

def ft_to_mm(v):
    return (v or 0.0) * FT_TO_MM

def get_double_param(elem, bip_names, name_candidates):
    """Try BuiltInParameters (by name) then named parameters. Return FEET or None."""
    # Try BuiltInParameters
    for bip_name in bip_names or []:
        try:
            bip = getattr(DB.BuiltInParameter, bip_name)
        except:
            bip = None
        if not bip:
            continue
        try:
            p = elem.get_Parameter(bip)
            if p and p.StorageType == DB.StorageType.Double:
                return p.AsDouble()
        except:
            pass
    # Try named parameters
    for nm in name_candidates or []:
        try:
            p = elem.LookupParameter(nm)
            if p and p.StorageType == DB.StorageType.Double:
                return p.AsDouble()
        except:
            pass
    return None

def run_width_mm(stairs_run):
    # Try a few ways to read run width
    ft = None
    # BuiltInParameter for run width if available
    try:
        bip = DB.BuiltInParameter.STAIRS_RUN_WIDTH
        p = stairs_run.get_Parameter(bip)
        if p and p.StorageType == DB.StorageType.Double:
            ft = p.AsDouble()
    except:
        pass
    if ft is None:
        # Named fallbacks
        for nm in ["Run Width", "Tread Width", "Width"]:
            try:
                p = stairs_run.LookupParameter(nm)
                if p and p.StorageType == DB.StorageType.Double:
                    ft = p.AsDouble()
                    break
            except:
                pass
    return ft_to_mm(ft) if ft is not None else None

# -------- Collect stairs, runs, and railings --------
stairs_all = list(DB.FilteredElementCollector(doc)
                  .OfCategory(DB.BuiltInCategory.OST_Stairs)
                  .WhereElementIsNotElementType())

runs_all = list(DB.FilteredElementCollector(doc)
                .OfCategory(DB.BuiltInCategory.OST_StairsRuns)
                .WhereElementIsNotElementType())

# Railings may be in OST_Railings and/or OST_StairsRailing depending on version
railings = []
railings += list(DB.FilteredElementCollector(doc)
                 .OfCategory(DB.BuiltInCategory.OST_Railings)
                 .WhereElementIsNotElementType())
try:
    railings += list(DB.FilteredElementCollector(doc)
                     .OfCategory(DB.BuiltInCategory.OST_StairsRailing)
                     .WhereElementIsNotElementType())
except:
    pass

# Group runs by their parent stairs
runs_by_stairs = {}
for run in runs_all:
    sid = None
    # On most builds: run.Stairs returns an Arch.Stairs reference
    try:
        if hasattr(run, "Stairs") and run.Stairs:
            sid = run.Stairs.Id
    except:
        sid = None
    if not sid:
        # fallback: try a host parameter (not always available)
        try:
            sid = run.HostId
        except:
            sid = None
    if not sid:
        continue
    runs_by_stairs.setdefault(sid, []).append(run)

# Group railings by host stairs id (Railing.HostId)
railings_by_stairs = {}
for rl in railings:
    hid = None
    try:
        hid = rl.HostId  # ElementId
    except:
        hid = None
    if not hid or hid.IntegerValue <= 0:
        continue

    host_elem = None
    try:
        host_elem = doc.GetElement(hid)
    except:
        host_elem = None

    # Prefer class check via Architecture namespace; fallback to category
    is_stairs_host = False
    try:
        is_stairs_host = isinstance(host_elem, Arch.Stairs)
    except:
        is_stairs_host = False
    if (not is_stairs_host) and host_elem and host_elem.Category:
        try:
            is_stairs_host = (host_elem.Category.Id.IntegerValue == int(DB.BuiltInCategory.OST_Stairs))
        except:
            pass

    if is_stairs_host:
        railings_by_stairs.setdefault(hid, []).append(rl)

# -------- Evaluate compliance --------
stairs_missing = []       # (stairsId, name, railing_count, required_count, widest_run_mm)
handrail_height_viol = [] # (railingId, name, measured_mm, range_str)
handrail_clear_viol  = [] # (railingId, name, measured_mm, required_mm)
violate_eids = []         # for highlighting

for st in stairs_all:
    sid = st.Id
    # Widest run width (mm)
    widest_mm = 0.0
    for r in runs_by_stairs.get(sid, []):
        w = run_width_mm(r)
        if w and w > widest_mm:
            widest_mm = w

    # Required number of railings
    required_count = 2 if (widest_mm and widest_mm >= DUAL_HANDRAIL_AT_WIDTH_MM) else 1
    rl_list = railings_by_stairs.get(sid, [])
    provided = len(rl_list)

    if provided < required_count:
        stairs_missing.append((sid.IntegerValue, getattr(st, "Name", "") or "", provided, required_count, int(round(widest_mm))))
        violate_eids.append(sid)

    # Check each railing on this stair for height & clearance
    for rl in rl_list:
        rid = rl.Id.IntegerValue
        rname = ""
        try:
            rname = rl.Name or ""
        except:
            pass

        # Handrail height (try BIP then names)
        h_ft = get_double_param(rl, BIP_HEIGHT_CAND, NAME_HEIGHT_CAND)
        if h_ft is not None:
            h_mm = round(ft_to_mm(h_ft), 1)
            if not (MIN_HEIGHT_MM - 1e-6 <= h_mm <= MAX_HEIGHT_MM + 1e-6):
                handrail_height_viol.append((rid, rname, h_mm, "{}–{} mm".format(int(MIN_HEIGHT_MM), int(MAX_HEIGHT_MM))))
                violate_eids.append(rl.Id)

        # Clearance (only if parameter exists)
        clr_ft = None
        for nm in NAME_CLEAR_CAND:
            try:
                p = rl.LookupParameter(nm)
                if p and p.StorageType == DB.StorageType.Double:
                    clr_ft = p.AsDouble()
                    break
            except:
                pass
        if clr_ft is not None:
            clr_mm = round(ft_to_mm(clr_ft), 1)
            if clr_mm + 1e-6 < MIN_CLEARANCE_MM:
                handrail_clear_viol.append((rid, rname, clr_mm, int(MIN_CLEARANCE_MM)))
                violate_eids.append(rl.Id)

# -------- Highlight & select --------
if HIGHLIGHT and violate_eids:
    ogs = DB.OverrideGraphicSettings()
    try:
        fp = DB.FillPatternElement.GetFillPatternElementByName(
            doc, DB.FillPatternTarget.Surface, "Solid fill"
        )
        if fp:
            ogs.SetSurfaceForegroundPatternId(fp.Id)
            ogs.SetSurfaceForegroundPatternColor(DB.Color(255, 0, 0))
            ogs.SetSurfaceTransparency(65)
    except:
        pass
    t = DB.Transaction(doc, "NFPA Stair Handrail Highlight")
    t.Start()
    try:
        for eid in set(violate_eids):
            view.SetElementOverrides(eid, ogs)
    finally:
        t.Commit()

if SELECT and violate_eids:
    try:
        cl = ClrList[DB.ElementId]()
        for eid in set(violate_eids):
            cl.Add(eid)
        uidoc.Selection.SetElementIds(cl)
    except:
        pass

# -------- Report --------
out.print_md("## NFPA — Stair Handrail Check")
out.print_md("- Height range: **{}–{} mm**, Min clearance: **{} mm**".format(int(MIN_HEIGHT_MM), int(MAX_HEIGHT_MM), int(MIN_CLEARANCE_MM)))
out.print_md("- Dual handrails required when widest run ≥ **{} mm**".format(int(DUAL_HANDRAIL_AT_WIDTH_MM)))

any_viol = False

if stairs_missing:
    any_viol = True
    out.print_md("\n### 🔴 Stairs with insufficient number of handrails")
    out.print_md("| Stairs Id | Name | Railings Provided | Railings Required | Widest Run (mm) |")
    out.print_md("|---:|---|---:|---:|---:|")
    for sid, nm, prov, req, wmm in stairs_missing:
        out.print_md("| {} | {} | {} | {} | {} |".format(sid, nm, prov, req, wmm))

if handrail_height_viol:
    any_viol = True
    out.print_md("\n### 🔴 Handrail height out of range")
    out.print_md("| Railing Id | Name | Measured (mm) | Allowed Range |")
    out.print_md("|---:|---|---:|---|")
    for rid, nm, meas, rng in handrail_height_viol:
        out.print_md("| {} | {} | {} | {} |".format(rid, nm, meas, rng))

if handrail_clear_viol:
    any_viol = True
    out.print_md("\n### 🔴 Handrail clearance below minimum")
    out.print_md("| Railing Id | Name | Measured (mm) | Required (mm) |")
    out.print_md("|---:|---|---:|---:|")
    for rid, nm, meas, req in handrail_clear_viol:
        out.print_md("| {} | {} | {} | {} |".format(rid, nm, meas, req))

if not any_viol:
    out.print_md("\n✅ All checked stairs/handrails meet configured NFPA limits.")

out.print_md("\nDone.")
