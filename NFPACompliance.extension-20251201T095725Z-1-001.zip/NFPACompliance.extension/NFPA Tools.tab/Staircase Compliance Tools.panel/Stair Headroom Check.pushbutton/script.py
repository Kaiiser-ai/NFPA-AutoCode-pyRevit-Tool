# -*- coding: utf-8 -*-
# pyRevit | NFPA Stair Headroom Check (Version A - parameter-based)
# Checks stair RUNS (and landings, optional) against a minimum headroom using
# an existing parameter on the elements (fast & stable).
#
# If a stair run (or landing) does not have a recognizable headroom parameter,
# it will be listed under "No headroom parameter found".

from pyrevit import revit, DB, script
from System.Collections.Generic import List as ClrList

# ---------------- USER SETTINGS ----------------
MIN_HEADROOM_MM = 2032.0   # NFPA/IBC common minimum headroom = 2032 mm (80 in)
CHECK_LANDINGS  = True     # also check stair landings if they expose a headroom param
HIGHLIGHT       = True
SELECT          = False
# ------------------------------------------------

doc   = revit.doc
uidoc = revit.uidoc
view  = doc.ActiveView
out   = script.get_output()

FT_TO_MM = 304.8

# Try these BuiltInParameters first (some may not exist on your Revit version/family)
BIP_CANDIDATES = [
    "STAIRS_HEADROOM_CLEARANCE",
    "STAIRS_MINIMUM_HEADROOM",
    "STAIRS_ACTUAL_HEADROOM",
    "STAIRS_RUN_MINIMUM_HEAD_CLEARANCE",
    "STAIRS_RUN_HEADROOM",
]

# Fallback parameter names as they may appear in families/templates
NAME_CANDIDATES = [
    "Headroom",
    "Head Room",
    "Headroom Clearance",
    "Minimum Headroom",
    "Min Headroom",
    "Clear Headroom",
]

def get_double_param(elem, bip_candidates, name_candidates):
    """Return value in FEET if a double parameter is found, else None."""
    # Try BuiltInParameters by name if they exist on this Revit API
    for bip_name in bip_candidates:
        try:
            bip = getattr(DB.BuiltInParameter, bip_name)
        except:
            bip = None
        if bip is None:
            continue
        try:
            p = elem.get_Parameter(bip)
            if p and p.StorageType == DB.StorageType.Double:
                return p.AsDouble()
        except:
            pass

    # Try named parameters on the element
    for nm in name_candidates:
        try:
            p = elem.LookupParameter(nm)
            if p and p.StorageType == DB.StorageType.Double:
                return p.AsDouble()
        except:
            pass
    return None

def mm(feet_val):
    return (feet_val or 0.0) * FT_TO_MM


# -------- Collect elements --------
runs = list(DB.FilteredElementCollector(doc)
            .OfCategory(DB.BuiltInCategory.OST_StairsRuns)
            .WhereElementIsNotElementType())

landings = []
if CHECK_LANDINGS:
    landings = list(DB.FilteredElementCollector(doc)
                    .OfCategory(DB.BuiltInCategory.OST_StairsLandings)
                    .WhereElementIsNotElementType())

out.print_md("## NFPA — Stair Headroom Check (Parameter-Based)")
out.print_md("- Minimum headroom: **{} mm**".format(int(MIN_HEADROOM_MM)))
out.print_md("- Runs found: **{}**{}".format(len(runs), " | Landings: **{}**".format(len(landings)) if CHECK_LANDINGS else ""))

viol_eids = []
no_param_runs = []
no_param_landings = []

viol_rows_runs = []     # (Id, Name, Measured_mm, Required_mm)
viol_rows_landings = [] # (Id, Name, Measured_mm, Required_mm)

# -------- Check RUNS --------
for r in runs:
    rid = r.Id.IntegerValue
    name = ""
    try: name = r.Name or ""
    except: pass

    hv_ft = get_double_param(r, BIP_CANDIDATES, NAME_CANDIDATES)
    if hv_ft is None:
        no_param_runs.append((rid, name))
        continue

    hv_mm = round(mm(hv_ft), 1)
    if hv_mm + 1e-6 < MIN_HEADROOM_MM:
        viol_rows_runs.append((rid, name, hv_mm, MIN_HEADROOM_MM))
        viol_eids.append(r.Id)

# -------- Check LANDINGS (optional) --------
if CHECK_LANDINGS:
    for ld in landings:
        lid = ld.Id.IntegerValue
        name = ""
        try: name = ld.Name or ""
        except: pass

        hv_ft = get_double_param(ld, BIP_CANDIDATES, NAME_CANDIDATES)
        if hv_ft is None:
            no_param_landings.append((lid, name))
            continue

        hv_mm = round(mm(hv_ft), 1)
        if hv_mm + 1e-6 < MIN_HEADROOM_MM:
            viol_rows_landings.append((lid, name, hv_mm, MIN_HEADROOM_MM))
            viol_eids.append(ld.Id)

# -------- Highlight & Select --------
if HIGHLIGHT and viol_eids:
    ogs = DB.OverrideGraphicSettings()
    try:
        fp = DB.FillPatternElement.GetFillPatternElementByName(
            doc, DB.FillPatternTarget.Surface, "Solid fill"
        )
        if fp:
            ogs.SetSurfaceForegroundPatternId(fp.Id)
            ogs.SetSurfaceForegroundPatternColor(DB.Color(255, 0, 0))
            ogs.SetSurfaceTransparency(65)
    except:
        pass

    t = DB.Transaction(doc, "NFPA Stair Headroom Highlight")
    t.Start()
    try:
        for eid in set(viol_eids):
            view.SetElementOverrides(eid, ogs)
    finally:
        t.Commit()

if SELECT and viol_eids:
    try:
        cl = ClrList[DB.ElementId]()
        for eid in set(viol_eids): cl.Add(eid)
        uidoc.Selection.SetElementIds(cl)
    except:
        pass

# -------- Report --------
any_viol = (len(viol_rows_runs) + len(viol_rows_landings)) > 0

if any_viol:
    if viol_rows_runs:
        out.print_md("### 🔴 Runs with headroom < {} mm".format(int(MIN_HEADROOM_MM)))
        out.print_md("| Run Id | Name | Measured (mm) | Required (mm) |")
        out.print_md("|---:|---|---:|---:|")
        for rid, nm, meas, req in viol_rows_runs:
            out.print_md("| {} | {} | {} | {} |".format(rid, nm, meas, int(req)))

    if viol_rows_landings:
        out.print_md("\n### 🔴 Landings with headroom < {} mm".format(int(MIN_HEADROOM_MM)))
        out.print_md("| Landing Id | Name | Measured (mm) | Required (mm) |")
        out.print_md("|---:|---|---:|---:|")
        for lid, nm, meas, req in viol_rows_landings:
            out.print_md("| {} | {} | {} | {} |".format(lid, nm, meas, int(req)))
else:
    out.print_md("✅ All checked runs{} meet the minimum headroom.".format(
        " and landings" if CHECK_LANDINGS else ""
    ))

# Missing parameter info
if no_param_runs:
    out.print_md("\nℹ️ Runs without a recognizable headroom parameter: **{}**".format(len(no_param_runs)))
    for rid, nm in no_param_runs:
        out.print_md("- Run Id {} ('{}')".format(rid, nm))

if CHECK_LANDINGS and no_param_landings:
    out.print_md("\nℹ️ Landings without a recognizable headroom parameter: **{}**".format(len(no_param_landings)))
    for lid, nm in no_param_landings:
        out.print_md("- Landing Id {} ('{}')".format(lid, nm))

out.print_md("\nDone.")
