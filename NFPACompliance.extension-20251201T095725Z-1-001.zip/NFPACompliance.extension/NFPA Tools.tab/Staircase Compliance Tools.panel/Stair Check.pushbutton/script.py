# -*- coding: utf-8 -*-
# pyRevit | NFPA Stair Run Checker (IronPython-safe)
# Checks stair runs for:
#   - Max riser height (mm)
#   - Min tread depth (mm)
#   - Min clear run width (mm)
# Highlights violations and prints a report.

from pyrevit import revit, DB, script
import math
from System.Collections.Generic import List as ClrList

# ------------- USER SETTINGS -------------
MAX_RISER_MM   = 180.0    # typical NFPA: ~7 in (177–180 mm)
MIN_TREAD_MM   = 280.0    # typical NFPA: ~11 in (279–280 mm)
MIN_WIDTH_MM   = 1100.0   # corridor/egress stair width (set 915 or other if allowed)

HIGHLIGHT = True
SELECT    = False
# ----------------------------------------

doc   = revit.doc
uidoc = revit.uidoc
view  = doc.ActiveView
out   = script.get_output()

FT_TO_MM  = 304.8

def get_double_param(elem, bip, names):
    """Try BuiltInParameter first, then list of parameter names. Returns None if not found."""
    # BuiltInParameter
    try:
        if bip is not None:
            p = elem.get_Parameter(bip)
            if p and p.StorageType == DB.StorageType.Double:
                return p.AsDouble()
    except:
        pass
    # Named params
    if names:
        for nm in names:
            try:
                p = elem.LookupParameter(nm)
                if p and p.StorageType == DB.StorageType.Double:
                    return p.AsDouble()
            except:
                pass
    return None

def mm(val_ft):
    return (val_ft or 0.0) * FT_TO_MM

# Collect all stair runs
runs = list(DB.FilteredElementCollector(doc)
            .OfCategory(DB.BuiltInCategory.OST_StairsRuns)
            .WhereElementIsNotElementType())

if not runs:
    out.print_md("## NFPA — Stair Check\nNo stair runs found in this model/view.")
    script.exit()

# Prepare report containers
viol_width = []   # (runId, name, measured_mm, required_mm)
viol_riser = []   # (runId, name, measured_mm, required_mm)
viol_tread = []   # (runId, name, measured_mm, required_mm)
all_viol_eids = []

# Iterate runs
for r in runs:
    rid = r.Id.IntegerValue
    # Friendly name
    try:
        nm = r.Name or ""
    except:
        nm = ""

    # 1) Riser height (Actual Riser Height)
    # Try official BIP then several common names used by Revit UI
    riser_ft = get_double_param(
        r,
        DB.BuiltInParameter.STAIRS_ACTUAL_RISER_HEIGHT if hasattr(DB.BuiltInParameter, "STAIRS_ACTUAL_RISER_HEIGHT") else None,
        ["Actual Riser Height", "Riser Height"]
    )
    # 2) Tread depth (Actual Tread Depth)
    tread_ft = get_double_param(
        r,
        DB.BuiltInParameter.STAIRS_ACTUAL_TREAD_DEPTH if hasattr(DB.BuiltInParameter, "STAIRS_ACTUAL_TREAD_DEPTH") else None,
        ["Actual Tread Depth", "Tread Depth"]
    )
    # 3) Run width (Run Width / Tread Width)
    width_ft = get_double_param(
        r,
        DB.BuiltInParameter.STAIRS_RUN_WIDTH if hasattr(DB.BuiltInParameter, "STAIRS_RUN_WIDTH") else None,
        ["Run Width", "Tread Width", "Width"]
    )

    # Check against limits
    if riser_ft is not None:
        riser_mm = round(mm(riser_ft), 1)
        if riser_mm > MAX_RISER_MM + 1e-6:
            viol_riser.append((rid, nm, riser_mm, MAX_RISER_MM))
            all_viol_eids.append(r.Id)

    if tread_ft is not None:
        tread_mm = round(mm(tread_ft), 1)
        if tread_mm + 1e-6 < MIN_TREAD_MM:
            viol_tread.append((rid, nm, tread_mm, MIN_TREAD_MM))
            all_viol_eids.append(r.Id)

    if width_ft is not None:
        width_mm = round(mm(width_ft), 1)
        if width_mm + 1e-6 < MIN_WIDTH_MM:
            viol_width.append((rid, nm, width_mm, MIN_WIDTH_MM))
            all_viol_eids.append(r.Id)

# Highlight all violating runs
if HIGHLIGHT and all_viol_eids:
    ogs = DB.OverrideGraphicSettings()
    try:
        fp = DB.FillPatternElement.GetFillPatternElementByName(
            doc, DB.FillPatternTarget.Surface, "Solid fill"
        )
        if fp:
            ogs.SetSurfaceForegroundPatternId(fp.Id)
            ogs.SetSurfaceForegroundPatternColor(DB.Color(255, 0, 0))
            ogs.SetSurfaceTransparency(65)
    except:
        pass
    t = DB.Transaction(doc, "NFPA Stair Run Highlight")
    t.Start()
    try:
        for eid in set(all_viol_eids):
            view.SetElementOverrides(eid, ogs)
    finally:
        t.Commit()

if SELECT and all_viol_eids:
    try:
        cl = ClrList[DB.ElementId]()
        for eid in set(all_viol_eids):
            cl.Add(eid)
        uidoc.Selection.SetElementIds(cl)
    except:
        pass

# -------- Report --------
out.print_md("## NFPA — Stair Run Compliance")
out.print_md("- Limits: Max Riser **{} mm**, Min Tread **{} mm**, Min Width **{} mm**".format(
    int(MAX_RISER_MM), int(MIN_TREAD_MM), int(MIN_WIDTH_MM)
))
out.print_md("- Runs checked: **{}**".format(len(runs)))

any_viol = False

if viol_riser:
    any_viol = True
    out.print_md("\n### 🔴 Riser Height Violations")
    out.print_md("| Run Id | Name | Measured (mm) | Required Max (mm) |")
    out.print_md("|---:|---|---:|---:|")
    for rid, nm, meas, req in viol_riser:
        out.print_md("| {} | {} | {} | {} |".format(rid, nm, meas, int(req)))

if viol_tread:
    any_viol = True
    out.print_md("\n### 🔴 Tread Depth Violations")
    out.print_md("| Run Id | Name | Measured (mm) | Required Min (mm) |")
    out.print_md("|---:|---|---:|---:|")
    for rid, nm, meas, req in viol_tread:
        out.print_md("| {} | {} | {} | {} |".format(rid, nm, meas, int(req)))

if viol_width:
    any_viol = True
    out.print_md("\n### 🔴 Run Width Violations")
    out.print_md("| Run Id | Name | Measured (mm) | Required Min (mm) |")
    out.print_md("|---:|---|---:|---:|")
    for rid, nm, meas, req in viol_width:
        out.print_md("| {} | {} | {} | {} |".format(rid, nm, meas, int(req)))

if not any_viol:
    out.print_md("\n✅ All stair runs meet the configured NFPA limits.")

out.print_md("\nDone.")
