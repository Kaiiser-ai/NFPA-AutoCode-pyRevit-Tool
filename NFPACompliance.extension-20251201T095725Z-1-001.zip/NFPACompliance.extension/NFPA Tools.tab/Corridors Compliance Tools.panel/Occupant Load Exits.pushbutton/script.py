# -*- coding: utf-8 -*-
from Autodesk.Revit.DB import FilteredElementCollector, BuiltInCategory
from pyrevit import revit, script

output = script.get_output()
doc = revit.doc

# NFPA Load Factors (m²/person) — adjust for your project
LOAD_FACTORS = {
    "bedroom": 18.6,
    "office": 9.3,
    "assembly": 2.8,
    "bathroom": 3.0,   # example, not usually critical
    "default": 18.6
}

def get_load_factor(name):
    lname = name.lower()
    for key in LOAD_FACTORS:
        if key in lname:
            return LOAD_FACTORS[key]
    return LOAD_FACTORS["default"]

def required_exits(occupants):
    if occupants <= 49:
        return 1
    elif occupants <= 500:
        return 2
    elif occupants <= 1000:
        return 3
    else:
        return 4

results = []
rooms = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_Rooms).WhereElementIsNotElementType()

for room in rooms:
    try:
        name = room.LookupParameter("Name").AsString()
        area = room.Area
        factor = get_load_factor(name)
        occ = int(round(area / factor, 0))

        # Count doors connected to this room
        provided_exits = 0
        try:
            provided_exits = 1  # assume at least 1 door (you can replace with door collector logic)
        except:
            provided_exits = 0

        req_exits = required_exits(occ)
        status = "✓ OK" if provided_exits >= req_exits else "❌ Not enough exits"

        results.append([room.Id.IntegerValue, name, round(area, 1), occ, req_exits, provided_exits, status])

    except Exception as e:
        results.append([room.Id.IntegerValue, "Error", "-", "-", "-", "-", str(e)])

# Print Results
output.print_table(
    table_data=results,
    title="NFPA Occupant Load Exit Check",
    columns=["RoomId", "Room Name", "Area (m²)", "Occupants", "Required", "Provided", "Status"]
)
