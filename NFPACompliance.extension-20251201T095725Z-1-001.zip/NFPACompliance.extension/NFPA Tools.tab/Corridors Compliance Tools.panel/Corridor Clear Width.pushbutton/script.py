# -*- coding: utf-8 -*-
from pyrevit import revit, DB, script

# NFPA minimum corridor clear width in mm
MIN_CORRIDOR_WIDTH = 1100  

output = script.get_output()
output.print_md("### 🚧 Corridor Width NFPA Check")

collector = DB.FilteredElementCollector(revit.doc).OfCategory(DB.BuiltInCategory.OST_Rooms).WhereElementIsNotElementType()

violations = []
for room in collector:
    name_param = room.LookupParameter("Name")
    if name_param:
        room_name = name_param.AsString()
        if "Corridor" in room_name:
            try:
                # Try to get room dimensions from bounding box
                bbox = room.get_BoundingBox(revit.doc.ActiveView)
                if bbox:
                    width = bbox.Max.X - bbox.Min.X
                    depth = bbox.Max.Y - bbox.Min.Y
                    # Convert from feet to mm
                    min_dim_mm = min(width, depth) * 304.8  

                    if min_dim_mm < MIN_CORRIDOR_WIDTH:
                        violations.append((room.Id, round(min_dim_mm, 1)))
                        output.print_md(
                            "Corridor ID {} width only **{} mm** (below {})".format(room.Id, round(min_dim_mm, 1), MIN_CORRIDOR_WIDTH)
                        )
            except Exception as e:
                output.print_md("Error checking corridor {}: {}".format(room.Id, str(e)))

if not violations:
    output.print_md("✅ All corridors meet NFPA minimum width of {} mm.".format(MIN_CORRIDOR_WIDTH))
else:
    output.print_md("🔴 {} corridor(s) failed the NFPA check.".format(len(violations)))
