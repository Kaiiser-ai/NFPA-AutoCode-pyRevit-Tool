# -*- coding: utf-8 -*-
from pyrevit import revit, DB, script

# NFPA limits
MAX_DEADEND_UNSPRINKLERED = 6096   # mm (20 ft)
MAX_DEADEND_SPRINKLERED  = 15240  # mm (50 ft)

# Output setup
output = script.get_output()
output.print_md("## 🚧 NFPA Dead-End Corridor Check")

# Collect corridor rooms
rooms = DB.FilteredElementCollector(revit.doc)\
          .OfCategory(DB.BuiltInCategory.OST_Rooms)\
          .WhereElementIsNotElementType()

violations = []

for room in rooms:
    try:
        name = room.LookupParameter("Name").AsString()
        if "corridor" in name.lower():
            # Get room geometry
            loc = room.Location
            if hasattr(loc, "Point"):
                # Approximate: measure distance from room centroid to nearest door
                centroid = loc.Point
                doors = DB.FilteredElementCollector(revit.doc)\
                        .OfCategory(DB.BuiltInCategory.OST_Doors)\
                        .WhereElementIsNotElementType()

                min_dist = None
                for door in doors:
                    door_loc = door.Location
                    if hasattr(door_loc, "Point"):
                        dist = centroid.DistanceTo(door_loc.Point) * 304.8  # feet→mm
                        if not min_dist or dist < min_dist:
                            min_dist = dist

                # Check against NFPA thresholds
                if min_dist:
                    if min_dist > MAX_DEADEND_UNSPRINKLERED:  # adjust if sprinklered
                        violations.append((room.Id, round(min_dist, 1)))
                        output.print_md("❌ Corridor {0} dead-end {1} mm".format(room.Id, round(min_dist, 1)))

    except Exception as e:
        output.print_md("⚠ Error with room {0}: {1}".format(room.Id, str(e)))

if not violations:
    output.print_md("✅ All corridors comply with NFPA dead-end limits.")
else:
    output.print_md("🔴 {0} corridor(s) exceed NFPA dead-end length.".format(len(violations)))
