# -*- coding: utf-8 -*-
from Autodesk.Revit.DB import FilteredElementCollector, BuiltInCategory
from Autodesk.Revit.DB import XYZ
from pyrevit import revit, script

output = script.get_output()

# Get the active Revit document safely
doc = revit.doc
if not doc:
    output.print_md("❌ No active Revit document found.")
    raise Exception("No active Revit document.")

# Collect corridors (rooms/areas named 'Corridor')
corridors = []
collector = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_Rooms).WhereElementIsNotElementType()
for room in collector:
    try:
        name = room.LookupParameter("Name").AsString()
        if name and "corridor" in name.lower():
            corridors.append(room)
    except:
        continue

# Collect exit stairs (rooms named 'Exit Stairs')
exits = []
for room in collector:
    try:
        name = room.LookupParameter("Name").AsString()
        if name and "exit stairs" in name.lower():
            exits.append(room)
    except:
        continue

if not exits:
    output.print_md("⚠️ No exit stairs found in the model.")
else:
    output.print_md("✅ Found {} exit stairs.".format(len(exits)))

# Simple distance check (room location to exit location)
from math import sqrt

def distance(pt1, pt2):
    return sqrt((pt1.X - pt2.X)**2 + (pt1.Y - pt2.Y)**2)

results = []
for corridor in corridors:
    loc = corridor.Location
    if not loc: 
        results.append([corridor.Id, "Corridor", "-", "❌ No location"])
        continue

    # Corridor centroid
    bbox = corridor.get_BoundingBox(None)
    mid = (bbox.Min + bbox.Max) * 0.5

    min_dist = None
    for exitroom in exits:
        bbox_exit = exitroom.get_BoundingBox(None)
        mid_exit = (bbox_exit.Min + bbox_exit.Max) * 0.5
        d = distance(mid, mid_exit)
        if min_dist is None or d < min_dist:
            min_dist = d

    if min_dist is None:
        results.append([corridor.Id, "Corridor", "-", "❌ No exit stairs found"])
    else:
        results.append([corridor.Id, "Corridor", round(min_dist, 2), "✓ OK"])

# Print results as table
output.print_table(
    table_data=results,
    title="NFPA Corridor Travel Distance Check",
    columns=["CorridorId", "Name", "Nearest Exit (m)", "Status"]
)
