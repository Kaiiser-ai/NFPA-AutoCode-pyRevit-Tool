# -*- coding: utf-8 -*-
"""NFPA – Wall Fire Rating (Missing-Value Audit)"""

from pyrevit import script, forms
from Autodesk.Revit.DB import *

doc  = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument
view = doc.ActiveView
out  = script.get_output()

# ---------------- Config ----------------
# Try these parameter names in order. Add your firm standards here if needed.
FIRE_PARAM_CANDIDATES = [
    "Fire_Rating",        # matches your screenshot
    "Fire Rating",
    "FireRating",
    "FIRE_RATING",
]

HIGHLIGHT_MISSING = True         # set False if you don't want red overrides
COLOR_RED = Color(230, 40, 40)   # override color for missing values
# ----------------------------------------


def get_param_text(elem, names):
    """Return first non-empty string among the candidate parameter names."""
    for name in names:
        p = elem.LookupParameter(name)
        if p:
            # Try string first
            try:
                s = p.AsString()
                if s and s.strip():
                    return s.strip()
            except:
                pass
            # Fallback: value string (e.g., when parameter is numeric)
            try:
                sv = p.AsValueString()
                if sv and sv.strip():
                    return sv.strip()
            except:
                pass
    return None


def get_wall_meta(w):
    def _lvl(e):
        try:
            lvl = doc.GetElement(e.LevelId)
            return lvl.Name if lvl else ""
        except:
            return ""
    def _typ(e):
        try:
            return e.WallType.Name
        except:
            return ""
    def _mark(e):
        p = e.LookupParameter("Mark")
        try:
            return (p.AsString() or "").strip() if p else ""
        except:
            return ""
    return _lvl(w), _typ(w), _mark(w)


# Scope choice (Active view vs Entire model)
scope = forms.CommandSwitchWindow.show(
    ['Active view', 'Entire model'],
    message='Wall Fire Rating – choose scope to check:',
    default='Active view'
)
if not scope:
    script.exit()

collector = (FilteredElementCollector(doc, view.Id)
             if scope == 'Active view'
             else FilteredElementCollector(doc))

walls = (collector.OfCategory(BuiltInCategory.OST_Walls)
                  .WhereElementIsNotElementType()
                  .ToElements())

if not walls:
    forms.alert('No walls found for the chosen scope.', title='Wall Fire Rating')
    script.exit()

missing = []
ok = []

for w in walls:
    val = get_param_text(w, FIRE_PARAM_CANDIDATES)
    if val is None or val.strip() == "":
        missing.append(w)
    else:
        ok.append(w)

# Highlight missing in the active view
if HIGHLIGHT_MISSING and missing and scope == 'Active view':
    ogs = OverrideGraphicSettings()
    ogs.SetProjectionLineColor(COLOR_RED)
    ogs.SetCutLineColor(COLOR_RED)
    try:
        ogs.SetSurfaceTransparency(30)
    except:
        pass

    t = Transaction(doc, "Highlight walls missing Fire Rating")
    t.Start()
    for e in missing:
        view.SetElementOverrides(e.Id, ogs)
    t.Commit()

# Report
out.print_md("## NFPA – Wall Fire Rating (Missing-Value Audit)")
out.print_md("- Scope: **{}**".format(scope))
out.print_md("- Walls checked: **{}**".format(len(walls)))
out.print_md("- 🔴 Missing Fire Rating: **{}**".format(len(missing)))
out.print_md("- ✅ With value: **{}**".format(len(ok)))
out.print_md("---")

if missing:
    rows = []
    for w in missing:
        lvl, typ, mark = get_wall_meta(w)
        rows.append([w.Id.IntegerValue, lvl, typ, mark])
    out.print_table(
        table_data=rows,
        columns=["Id", "Level", "Type", "Mark"]
    )
    out.print_md(
        "\nUse the **Id** to select and fill the Fire Rating parameter "
        "(e.g., `Fire_Rating`) on these walls."
    )
else:
    out.print_md("🎉 No missing Fire Rating values found.")
