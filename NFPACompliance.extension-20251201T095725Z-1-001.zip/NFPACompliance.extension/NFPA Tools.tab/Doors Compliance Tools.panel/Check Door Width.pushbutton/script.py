# -*- coding: utf-8 -*-
__title__ = "Check Door Width"
__author__ = "NFPA Tool"

from pyrevit import revit, DB, script

MIN_WIDTH_MM = 813  # NFPA minimum clear width

output = script.get_output()
output.print_md("## 🚪 NFPA Door Width Compliance Check")

collector = DB.FilteredElementCollector(revit.doc)\
    .OfCategory(DB.BuiltInCategory.OST_Doors)\
    .WhereElementIsNotElementType()

violations = []

for door in collector:
    try:
        width_ft = None

        # First try instance parameter
        inst_param = door.LookupParameter("Width")
        if inst_param and inst_param.AsDouble() > 0:
            width_ft = inst_param.AsDouble()
        else:
            # Try type parameter
            door_type = revit.doc.GetElement(door.GetTypeId())
            type_param = door_type.LookupParameter("Width") if door_type else None
            if type_param and type_param.AsDouble() > 0:
                width_ft = type_param.AsDouble()

        if width_ft:
            width_mm = width_ft * 304.8

            # Skip bathroom/toilet doors
            room = None
            try:
                room = revit.doc.GetRoomAtPoint(door.Location.Point)
            except:
                pass
            if room and ("Toilet" in room.Name or "Bath" in room.Name):
                continue

            # NFPA check
            if width_mm < MIN_WIDTH_MM:
                violations.append((door.Id, round(width_mm, 1)))
                output.print_md("❌ Door ID {} too narrow: {} mm".format(door.Id, round(width_mm, 1)))

    except Exception as e:
        output.print_md("⚠️ Error with door {} : {}".format(door.Id, str(e)))

# Final message
if not violations:
    output.print_md("✅ All relevant doors meet the NFPA minimum width of {} mm.".format(MIN_WIDTH_MM))
else:
    output.print_md("🔴 {} door(s) are under the NFPA minimum width of {} mm.".format(len(violations), MIN_WIDTH_MM))
