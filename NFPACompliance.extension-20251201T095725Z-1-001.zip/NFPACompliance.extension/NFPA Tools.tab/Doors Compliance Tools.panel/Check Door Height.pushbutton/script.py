# -*- coding: utf-8 -*-
# pyRevit | NFPA — Door Height Check (IronPython 2.7, robust)

from pyrevit import revit, DB, script
from System.Collections.Generic import List

FT_TO_MM = 304.8
MIN_HEIGHT_MM = 2032.0          # Change if your minimum differs
HIGHLIGHT_AND_SELECT = True     # Set False if you don’t want red overrides/selection
DEBUG_MODE = False              # Set True to log doors where no height was found

out = script.get_output()
out.print_md(u"## NFPA — Door Height Check")
out.print_md(u"SCRIPT PATH: `{}`".format(script.get_script_path()))
out.print_md(u"Minimum required height: **{:.0f} mm**".format(MIN_HEIGHT_MM))

doc  = revit.doc
uidoc = revit.uidoc
view = doc.ActiveView

# -------------------------------- helpers --------------------------------
def is_length_param(p):
    try:
        return p and p.StorageType == DB.StorageType.Double
    except:
        return False

def as_mm(p):
    try:
        return p.AsDouble() * FT_TO_MM
    except:
        return None

# common parameter display names used by many door families
CANDIDATE_NAMES = [
    "Height", "Door Height", "Nominal Height", "Clear Height",
    "Frame Height", "Rough Height", "Head Height"
]

def try_get_height_mm(elem):
    """Try multiple ways to read door height (mm) from instance/type."""
    # 1) Built-in parameter
    try:
        p = elem.get_Parameter(DB.BuiltInParameter.DOOR_HEIGHT)
        if is_length_param(p):
            v = as_mm(p)
            if v: return v
    except:
        pass

    # 2) Named parameters on instance
    for n in CANDIDATE_NAMES:
        try:
            p = elem.LookupParameter(n)
            if is_length_param(p):
                v = as_mm(p)
                if v: return v
        except:
            pass

    # 3) Named parameters on type
    sym = getattr(elem, "Symbol", None)
    if sym:
        for n in CANDIDATE_NAMES:
            try:
                p = sym.LookupParameter(n)
                if is_length_param(p):
                    v = as_mm(p)
                    if v: return v
            except:
                pass

    # 4) Fallback scan: any length param with "height" in its name (instance then type)
    try:
        for p in elem.Parameters:
            try:
                nm = p.Definition.Name if p.Definition else ""
                if "height" in nm.lower() and is_length_param(p):
                    v = as_mm(p)
                    if v: return v
            except:
                pass
    except:
        pass

    if sym:
        try:
            for p in sym.Parameters:
                try:
                    nm = p.Definition.Name if p.Definition else ""
                    if "height" in nm.lower() and is_length_param(p):
                        v = as_mm(p)
                        if v: return v
                except:
                    pass
        except:
            pass

    return None

# -------------------------------- collect --------------------------------
doors = DB.FilteredElementCollector(doc)\
    .OfCategory(DB.BuiltInCategory.OST_Doors)\
    .WhereElementIsNotElementType()

# -------------------------------- style ----------------------------------
ogs = DB.OverrideGraphicSettings()
ogs.SetProjectionLineColor(DB.Color(255, 0, 0))
ogs.SetProjectionLineWeight(8)

viol_ids = List[DB.ElementId]()
viol_count = 0
skipped = 0

# -------------------------------- run ------------------------------------
with revit.Transaction(u"NFPA — Door Height: Highlight"):
    for d in doors:
        try:
            h_mm = try_get_height_mm(d)
            if h_mm is None:
                skipped += 1
                if DEBUG_MODE:
                    fam = ""
                    try:
                        fam = d.Symbol.Family.Name if d.Symbol and d.Symbol.Family else ""
                    except:
                        pass
                    out.print_md(u"⚠️ Skipped Door ID {} (Family: {}) — no readable height.".format(
                        d.Id.IntegerValue, fam))
                continue

            if h_mm + 0.001 < MIN_HEIGHT_MM:
                viol_ids.Add(d.Id)
                viol_count += 1

                if HIGHLIGHT_AND_SELECT:
                    try:
                        doc.ActiveView.SetElementOverrides(d.Id, ogs)
                    except Exception as e:
                        out.print_md(u"⚠️ Could not override Door ID {}: {}".format(
                            d.Id.IntegerValue, e))

                # Report line (include Mark if present)
                mark = ""
                try:
                    mp = d.LookupParameter("Mark")
                    mark = mp.AsString() if mp else ""
                except:
                    pass

                out.print_md(
                    u"- Door **ID {}** {} → **{:.0f} mm** < **{:.0f} mm**".format(
                        d.Id.IntegerValue,
                        u"(Mark: {})".format(mark) if mark else "",
                        h_mm, MIN_HEIGHT_MM
                    )
                )
        except Exception as e:
            skipped += 1
            if DEBUG_MODE:
                out.print_md(u"⚠️ Error on Door ID {}: {}".format(d.Id.IntegerValue, e))

# Select violating doors so user can review
if HIGHLIGHT_AND_SELECT:
    try:
        uidoc.Selection.SetElementIds(viol_ids)
    except:
        pass

# -------------------------------- summary --------------------------------
if viol_count:
    out.print_md(u"\n**Violations found:** {} door(s).{}".format(
        viol_count,
        u" Highlighted in red and selected." if HIGHLIGHT_AND_SELECT else u""
    ))
else:
    out.print_md(u"\n✅ All doors meet the minimum height of {:.0f} mm.".format(MIN_HEIGHT_MM))

if DEBUG_MODE and skipped:
    out.print_md(u"_{} door(s) had no readable height or produced errors._".format(skipped))
