# -*- coding: utf-8 -*-
# Missing Windows Checker for Rooms
# pyRevit Script

from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.Exceptions import InvalidOperationException

doc = __revit__.ActiveUIDocument.Document

# ✅ Get the latest phase (instead of using ActiveView by mistake)
phase_collector = FilteredElementCollector(doc).OfClass(Phase)
phases = list(phase_collector)
if not phases:
    print("⚠ No phases found in this project.")
    phase = None
else:
    phase = phases[-1]   # use the most recent phase

# Collect all rooms
rooms = FilteredElementCollector(doc)\
    .OfCategory(BuiltInCategory.OST_Rooms)\
    .WhereElementIsNotElementType()\
    .ToElements()

# Collect all windows
windows = FilteredElementCollector(doc)\
    .OfCategory(BuiltInCategory.OST_Windows)\
    .WhereElementIsNotElementType()\
    .ToElements()

# Build mapping of windows by host room
window_dict = {}
for w in windows:
    try:
        room = w.Room[phase]
        if room:
            rid = room.Id.IntegerValue
            if rid not in window_dict:
                window_dict[rid] = []
            window_dict[rid].append(w)
    except:
        pass

# Check each room for missing windows
print("🏠 NFPA - Missing Windows Check\n")
for room in rooms:
    try:
        rid = room.Id.IntegerValue
        rname = room.LookupParameter("Name").AsString()
        area = room.Area
        if rid not in window_dict:
            print("⚠ Room: {} | Area: {:.2f} m² | No windows found".format(rname, area))
        else:
            print("✔ Room: {} | Area: {:.2f} m² | Windows: {}".format(rname, area, len(window_dict[rid])))
    except Exception as e:
        print("⚠ Error with room {} : {}".format(room.Id.IntegerValue, str(e)))
