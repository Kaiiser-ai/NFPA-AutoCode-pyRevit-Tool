# -*- coding: utf-8 -*-
"""Rooms Missing Doors – robust (phase-safe + linked doors support)."""

from pyrevit import script, forms
from Autodesk.Revit.DB import *
from System.Collections.Generic import List

doc   = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument
view  = doc.ActiveView
out   = script.get_output()

# ---------------- Settings ----------------
COLOR_RED = Color(230, 40, 40)
STEP_FT   = 0.6     # ~180 mm offset from the door center to probe room on each side
AREA_EPS  = 1e-4    # room area ft² threshold (tiny rooms ignored)
# ------------------------------------------

def room_number(r):
    p = r.LookupParameter("Number")
    if p:
        s = p.AsString()
        return s.strip() if s else ""
    return ""

def room_name(r):
    p = r.LookupParameter("Name")
    if p:
        s = p.AsString()
        return s.strip() if s else ""
    return ""

def level_name(elem):
    try:
        lvl = doc.GetElement(elem.LevelId)
        return lvl.Name if lvl else ""
    except:
        return ""

def room_area_m2(r):
    try:
        p = r.get_Parameter(BuiltInParameter.ROOM_AREA)
        if p:
            a_ft2 = p.AsDouble()
            return a_ft2 * 0.092903
    except:
        pass
    return 0.0

def is_enclosed_room(r):
    try:
        p = r.get_Parameter(BuiltInParameter.ROOM_AREA)
        if not p:
            return False
        return p.AsDouble() > AREA_EPS
    except:
        return False

def get_view_phase(v):
    try:
        ph_id = v.get_Parameter(BuiltInParameter.VIEW_PHASE).AsElementId()
        if ph_id and ph_id != ElementId.InvalidElementId:
            return doc.GetElement(ph_id)
    except:
        pass
    # fallback: last phase
    try:
        phases = list(doc.Phases)
        if phases:
            return phases[-1]
    except:
        pass
    return None

def collect_rooms(scope_text):
    if scope_text == "Visible in Active View (fast)":
        return (FilteredElementCollector(doc, view.Id)
                .OfCategory(BuiltInCategory.OST_Rooms)
                .WhereElementIsNotElementType()
                .ToElements())
    elif scope_text == "Active View (all)":
        return (FilteredElementCollector(doc, view.Id)
                .OfCategory(BuiltInCategory.OST_Rooms)
                .WhereElementIsNotElementType()
                .ToElements())
    else:
        return (FilteredElementCollector(doc)
                .OfCategory(BuiltInCategory.OST_Rooms)
                .WhereElementIsNotElementType()
                .ToElements())

def highlight_rooms_in_view(rooms_to_color, color):
    if not rooms_to_color:
        return
    ogs = OverrideGraphicSettings()
    try:
        ogs.SetProjectionLineColor(color)
        ogs.SetCutLineColor(color)
        ogs.SetSurfaceTransparency(35)
    except:
        pass
    t = Transaction(doc, "Highlight Rooms (No Doors)")
    try:
        t.Start()
        for r in rooms_to_color:
            try:
                view.SetElementOverrides(r.Id, ogs)
            except:
                pass
        t.Commit()
    except:
        if t.HasStarted(): t.RollBack()

def door_probe_rooms_at_points(doc_host, point, facing):
    """Return up to two host rooms around a door using point-in-room tests."""
    rooms = []
    if not point:
        return rooms
    try:
        f = facing
        if not f or f.IsZeroLength():
            f = XYZ.BasisY
        f = f.Normalize()
    except:
        f = XYZ.BasisY
    try:
        p1 = point + f * STEP_FT
        p2 = point - f * STEP_FT
        r1 = doc_host.GetRoomAtPoint(p1)
        r2 = doc_host.GetRoomAtPoint(p2)
        if r1: rooms.append(r1)
        if r2 and (not r1 or r2.Id.IntegerValue != r1.Id.IntegerValue):
            rooms.append(r2)
    except:
        pass
    return rooms

def add_host_door_rooms(has_door_map, room_ids_set):
    doors = (FilteredElementCollector(doc)
             .OfCategory(BuiltInCategory.OST_Doors)
             .WhereElementIsNotElementType()
             .ToElements())
    count = 0
    for d in doors:
        try:
            loc = d.Location
            pt  = loc.Point if isinstance(loc, LocationPoint) else None
            face = None
            try:
                face = d.FacingOrientation
            except:
                pass
            rooms_near = door_probe_rooms_at_points(doc, pt, face)
            for r in rooms_near:
                rid = r.Id.IntegerValue
                if rid in room_ids_set:
                    has_door_map[rid] = True
            count += 1
        except:
            pass
    return count

def add_linked_door_rooms(has_door_map, room_ids_set):
    """Also consider doors in linked models (transform points into host)."""
    links = FilteredElementCollector(doc).OfClass(RevitLinkInstance).ToElements()
    link_door_count = 0
    for inst in links:
        link_doc = inst.GetLinkDocument()
        if not link_doc:
            continue
        trf = inst.GetTotalTransform()
        try:
            link_doors = (FilteredElementCollector(link_doc)
                          .OfCategory(BuiltInCategory.OST_Doors)
                          .WhereElementIsNotElementType()
                          .ToElements())
        except:
            link_doors = []
        for d in link_doors:
            try:
                loc = d.Location
                pt_link = loc.Point if isinstance(loc, LocationPoint) else None
                if not pt_link:
                    continue
                pt_host = trf.OfPoint(pt_link)
                # Facing orientation (if any) – transform as a vector
                face = None
                try:
                    v = d.FacingOrientation
                    if v:
                        face = trf.OfVector(v)
                except:
                    pass
                rooms_near = door_probe_rooms_at_points(doc, pt_host, face)
                for r in rooms_near:
                    rid = r.Id.IntegerValue
                    if rid in room_ids_set:
                        has_door_map[rid] = True
                link_door_count += 1
            except:
                pass
    return link_door_count

# ---------------- Run ----------------
phase = get_view_phase(view)
if not phase:
    forms.alert("Could not determine view phase. Try a phased plan or enable phases.", title="Rooms Missing Doors")
    script.exit()

scope = forms.CommandSwitchWindow.show(
    ["Visible in Active View (fast)", "Active View (all)", "Entire Model"],
    message="Rooms Missing Doors – choose scope:",
    default="Visible in Active View (fast)"
)
if not scope:
    script.exit()

resp = forms.alert("Include doors from linked models? (Recommended if doors live in Arch link.)",
                   yes=True, no=True, title="Include Linked Doors?")
include_links = True if resp else False

rooms_raw = collect_rooms(scope)
# keep only placed & enclosed
checked_rooms = []
for r in rooms_raw:
    try:
        if r.Location and is_enclosed_room(r):
            checked_rooms.append(r)
    except:
        pass

if not checked_rooms:
    forms.alert("No placed & enclosed rooms found for the chosen scope.", title="Rooms Missing Doors")
    script.exit()

has_door = {r.Id.IntegerValue: False for r in checked_rooms}
room_ids_set = set(has_door.keys())

# host doors
host_cnt = add_host_door_rooms(has_door, room_ids_set)
# linked doors (optional)
link_cnt = add_linked_door_rooms(has_door, room_ids_set) if include_links else 0

no_door_rooms = [r for r in checked_rooms if not has_door.get(r.Id.IntegerValue, False)]

# Optional highlight (only when not Entire Model)
if scope != "Entire Model" and no_door_rooms:
    do_hl = forms.alert("Highlight rooms with no doors in red?", yes=True, no=True, title="Highlight?")
    if do_hl:
        highlight_rooms_in_view(no_door_rooms, COLOR_RED)

# Report
out.print_md("## Rooms Missing Doors — Robust")
out.print_md("- Scope: **{}**".format(scope))
out.print_md("- Host doors checked: **{}**".format(host_cnt))
if include_links:
    out.print_md("- Linked doors checked: **{}**".format(link_cnt))
out.print_md("- Rooms checked (placed & enclosed): **{}**".format(len(checked_rooms)))
out.print_md("- 🔴 Rooms with NO doors: **{}**".format(len(no_door_rooms)))
out.print_md("---")

if no_door_rooms:
    rows = []
    for r in no_door_rooms:
        rows.append([
            out.linkify(r.Id),
            level_name(r),
            room_number(r) or "—",
            room_name(r) or "—",
            "{:.2f}".format(room_area_m2(r))
        ])
    out.print_table(rows, columns=["Id", "Level", "Number", "Name", "Area (m²)"])
    out.print_md("\n**Tip:** If you use linked architectural models for doors, keep the link loaded and ‘Include linked doors’ = Yes.")
else:
    out.print_md("🎉 All checked rooms have at least one door.")
