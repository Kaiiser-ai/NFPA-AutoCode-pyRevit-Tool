# -*- coding: utf-8 -*-
"""Room Audit – find Unplaced, Not Enclosed, and Missing Name/Number."""

from pyrevit import script, forms
from Autodesk.Revit.DB import *

doc   = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument
view  = doc.ActiveView
out   = script.get_output()

# ---------- Settings ----------
HIGHLIGHT_NOT_ENCLOSED = True     # highlight only in Active View
COLOR_RED = Color(230, 40, 40)
# -----------------------------


def get_text_param(elem, pname):
    """Return parameter text (Name/Number)."""
    p = elem.LookupParameter(pname)
    if not p: 
        return ""
    try:
        s = p.AsString()
        return s.strip() if s else ""
    except:
        try:
            vs = p.AsValueString()
            return vs.strip() if vs else ""
        except:
            return ""


def get_level_name(elem):
    try:
        lvl = doc.GetElement(elem.LevelId)
        return lvl.Name if lvl else ""
    except:
        return ""


# Scope
scope = forms.CommandSwitchWindow.show(
    ["Active view", "Entire model"],
    message="Missing Rooms – choose scope to check:",
    default="Active view"
)
if not scope:
    script.exit()

collector = (FilteredElementCollector(doc, view.Id)
             if scope == "Active view"
             else FilteredElementCollector(doc))

rooms = (collector.OfCategory(BuiltInCategory.OST_Rooms)
                 .WhereElementIsNotElementType()
                 .ToElements())

if not rooms:
    forms.alert("No rooms found for the chosen scope.", title="Missing Rooms")
    script.exit()

# Buckets
unplaced = []       # Location is None
not_enclosed = []   # placed but Area == 0
missing_meta = []   # placed and area>0 but missing Name/Number

for r in rooms:
    name   = get_text_param(r, "Name")
    number = get_text_param(r, "Number")
    lvl    = get_level_name(r)

    # placed or not
    placed = (r.Location is not None)

    # area
    area_ok = False
    try:
        area_ok = (r.Area > 0.0)
    except:
        area_ok = False

    if not placed:
        unplaced.append((r, lvl, name, number))
        continue

    if placed and not area_ok:
        not_enclosed.append((r, lvl, name, number))
        continue

    if (not name) or (not number):
        missing_meta.append((r, lvl, name, number))


# Highlight “Not Enclosed” in active view
if HIGHLIGHT_NOT_ENCLOSED and not_enclosed and scope == "Active view":
    ogs = OverrideGraphicSettings()
    ogs.SetProjectionLineColor(COLOR_RED)
    ogs.SetCutLineColor(COLOR_RED)
    try:
        ogs.SetSurfaceTransparency(40)
    except:
        pass

    t = Transaction(doc, "Highlight Not Enclosed Rooms")
    t.Start()
    for r, _, _, _ in not_enclosed:
        view.SetElementOverrides(r.Id, ogs)
    t.Commit()

# Report
out.print_md("## Room Audit (Missing & Issues)")
out.print_md("- Scope: **{}**".format(scope))
out.print_md("- Total rooms found: **{}**".format(len(rooms)))
out.print_md("---")

def print_bucket(title, items, empty_msg):
    out.print_md("### {}".format(title))
    if not items:
        out.print_md(empty_msg)
        out.print_md("---")
        return
    rows = []
    for r, lvl, name, number in items:
        rows.append([out.linkify(r.Id), lvl, number or "—", name or "—"])
    out.print_table(rows, columns=["Id", "Level", "Number", "Name"])
    out.print_md("---")

print_bucket("🔴 Unplaced Rooms",         unplaced,      "None 🎉")
print_bucket("🟥 Not Enclosed (Area = 0)", not_enclosed,  "None 🎉")
print_bucket("⚠️ Missing Name/Number",     missing_meta,  "None 🎉")

out.print_md(
    "**Tips**\n"
    "- *Unplaced*: Place the room on the correct level.\n"
    "- *Not Enclosed*: Ensure bounding walls/room separation lines fully enclose the room and that the view’s Room Computation Height is appropriate.\n"
    "- *Missing Name/Number*: Fill values in the Properties palette or Room schedule.\n"
)
